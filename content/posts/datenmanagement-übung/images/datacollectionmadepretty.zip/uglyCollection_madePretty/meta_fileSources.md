# File sources

## 2dImages

### drawingsPaintings
* `drawing_dameDucksLecture.jpg`: https://commons.wikimedia.org/wiki/File:Dame_Duck%27s_lecture_pg_6.jpg - Public Domain USA
* `drawing_duckPond_getty-84XO70231720.jpg`: https://www.getty.edu/art/collection/objects/144782/charles-francois-daubigny-le-marais-aux-canards-french-plate-1858-1862-print-1921/ - No Copyright USA
* `drawing_duckRoosterGoose_getty-83MR17225v.jpg`: https://www.getty.edu/art/collection/objects/4747/unknown-maker-a-duck-a-rooster-and-a-goose-cretan-1510-1520/  - No Copyright USA
* `drawing_wms_cAdele.jpg`: http://www.claireadele.com/projects/eierlegendewollmilchsau-illustration/ - in copyright
* `drawing_wms_pixelrausch`: https://commons.wikimedia.org/wiki/File:Wollmilchsau.png - CC BY-SA 2.0
* `painting_duckomentaSissi.jpg`: https://www.duckomenta-shop.de/shop/gem%C3%A4lde-repliken-ungerahmt/klassische-meister/ - in copyright; description: *Der Portraitist Franz Xaver Winterducker berichtet, Kaiserin Elisabeth habe sich für dieses Bildnis auf einen Stuhl gestellt, um ihr Lieblingskleid besser zur Geltung zu bringen. Von dem Motiv erstellt der Maler für zahlungskräftige Kunden mehrere Versionen. Das Geheimnis, welche Version die richtige ist, nimmt er mit ins Grab.* 
* `painting_duckomentaSissi_LIDO.xml`: Object metadata for `painting_duckomentaSissi.jpg` in LIDO format; schema: http://www.lido-schema.org/schema/v1.0/lido-v1.0.xsd


### other
* `clipart_wms_fGraf.jpg`: https://commons.wikimedia.org/wiki/File:EierlegendeWollmilchSau.jpg - CC BY-SA 3.0 (+DE)
* `coatOfArms_duckburg.svg`: https://commons.wikimedia.org/wiki/File:Blason_donaldville.svg (Yaya0108) - CC-BY-SA 4.0; description: *This is the coat of arms of the fictitious town of Donald Duck created by Carl Barks.*, created: 2020-05-09
* `stamp_donaldDaisyDuck_albania.jpeg`: https://commons.wikimedia.org/wiki/File:Stamp_of_Albania_-_2000_-_Colnect_370816_-_Donald_Duck_and_Daisy_Duck.jpeg - Public Domain


### photographs
* `photo_01icelandStoneDuck_Djupivogur.dng`: own work
* `photo_02icelandStoneDuck_Djupivogur.dng`: own work
* `photo_clayDuckNetsuke_bhm-ethno-262`: https://commons.wikimedia.org/wiki/File:Duck_netsuke-Ethno_BHM_262-P6141097-gradient.jpg - CC BY-SA 2.0, 3.0 FR 
* `photoCollage_wms_gMittenecker.jpg`: https://commons.wikimedia.org/wiki/File:Wollmilchsau.jpg - CC BY-SA 2.5
* `photo_duckAskos_getty-78AE280a.jpg`: https://www.getty.edu/art/collection/objects/8236/attributed-to-the-clusium-group-one-fragment-of-a-duck-askos-etruscan-about-400-bc/ - No Copyright USA
* `photo_streetArtEntenhausen.jpg`: own work
* `photo_streetArtEntenhausen_v02.jpg`: own work


### postcards
* `pc01_eDanielson_a.jpg` & `pc01_eDanielson_b.jpg`: https://www.hippostcard.com/listing/malmo-sweden-to-pasco-washington-usa-2002-die-cut-postcard-ducks-geese/29141918
* `pc02_constantArtz_a.jpg` & `pc02_constantArtz_b.jpg`: https://www.hippostcard.com/listing/united-kingdom-post-card-duckings-by-the-rivers-edge-by-constant-artz/33713484
* `pc03_warnerBros_a.jpg` & `pc03_warnerBros_b.jpg`: https://www.hippostcard.com/listing/postcard-daffy-duck-warner-brothers-i-live-down-by-pond-drop-in-pc1757/26347659
* `pc04_georgesLang_a.jpg` & `pc04_georgesLang_b.jpg`: https://www.hippostcard.com/listing/french-walt-disney-donald-duck-character-nephews-c1950s-pc-by-tobler-chocolate/31702830


## 3d
* `clayDuck` (& `clayDuck_glTF`): clay_duck.zip - https://sketchfab.com/3d-models/clay-duck-39259b33b5b24361b91f2211f3e71691 - CC BY
* `hopiDuckBowl_ypm-ant248958`: https://sketchfab.com/3d-models/ypm-ant248958-99bc606872cb44299b3041dc360ea5f6 - CC BY


## articles
* `article_wms_dad` all versions: Kamelopedia, Eierlegende Wollmilchsau http://kamelopedia.net/wiki/Eierlegende_Wollmilchsau - CC BY-SA 3.0
* `article_wms_dagd` versions 1-3: Stupidedia, Eierlegende Wollmilchsau https://www.stupidedia.org/stupi/Eierlegende_Wollmilchsau - GNU Free Documentation License 1.2
* `article_wms_dagd` version 4: GfdS - Gesellschaft für deutsche Sprache, Fragen und Antworten, Woher kommt die eierlegende Wollmilchsau? https://gfds.de/eierlegende-wollmilchsau/ 


## audio
* `recording_ente_sWallroth.wav`


## maps
* `map_duckburgDetail.jpg`: https://www.donald.org/stadtplan - in copyright; description: *A toy map from Entenhausen created by Jürgen Wollina. Low-resolution preview downloaded from https://www.donald.org/stadtplan*, created: 2020-05-09
* `map_duckburgDetail_annotation.ttl`: own work done in the annotation tool Recogito https://recogito.pelagios.org/, schema: http://www.w3.org/ns/oa#


## tables
* `table_duckCharacters_dod.csv`: own work
* `table_duckCharacters_dod.xlsx`: own work