Creation date: 2021-11-11
Author: Martina Trognitz

# Sample solution for organising `uglyCollection`

This is one way how `uglyCollection` could be organised considering best practices for file naming and folder structuring.

## Deleted files and folders
Several files were just simple copies which could safely be removed. Besides identical file names and file sizes other indicators for removal was the naming of folders like `0 OldFiles` or `tempDagobert`.

List of deleted folders and files. The deleted files and folders are marked with ~~strikethrough~~:
* ~~`0 OldFiles`~~
  * ~~`20210712_080947_entenhausen.jpg`~~
  * ~~`dieWollmilchsau.docx`~~
* `evenNewerStuff`
  * `3d`
    * `clay-duck`
      * `source`
        * `model.zip`
      * `textures`
        * `lambert1_albedo.jpeg`
        * `lambert1_AO.jpeg`
        * `lambert1_metallic.jpeg`
        * `lambert1_normal.png`
        * `lambert1_roughness.jpeg`
    * `ypm-ant248958`
      * `source`
        * `medium.zip`
      * `textures`
        * `mesh_medium_u1_v1.png`
    * `clay_duck_glTF.zip`
    * ~~`ypm-ant248958.zip`~~
  * `postcards`
    * `01-a.jpg`
    * `01-b.jpg`
    * `02-a.jpg`
    * `02-b.jpg`
    * `03-a.jpg`
    * `03-b.jpg`
    * `04-back.jpg`
    * `04-front.jpg`
  * `00540901.jpg`
  * `00938201.jpg`
  * `15896001.jpg`
  * `20210712_080947_entenhausen.jpg`
  * `20210712_080947_entenhausenCorr.jpg`
  * `Dame_Duck's_lecture_pg_6.jpg`
  * `DSC_5248_IslandOstfjorde Djúpivogur.dng`
  * ~~`DSC_5248_IslandOstfjorde Djúpivogur.jpg`~~
  * `DSC_5255_IslandOstfjorde Djúpivogur WIS.dng`
  * ~~`DSC_5255_IslandOstfjorde Djúpivogur WIS.jpg`~~
  * ~~`DSC_5255_IslandOstfjorde Djúpivogur WIS.tiff`~~
  * `Duck_netsuke-Ethno_BHM_262-P6141097-gradient.jpg`
  * `EierlegendeWollmilchSau.jpg`
  * `Eierlegendewollmilchsau-Claire-Adele-02.jpg`
  * `herkunft.md`
  * `Stamp_of_Albania_-_2000_-_Colnect_370816_-_Donald_Duck_and_Daisy_Duck.jpeg`
  * `Wollmilchsau.jpg`
  * `Wollmilchsau.png`
* `newStuff`
  * `Blason_donaldville.svg`
  * `docs_meta.txt`
  * `duck_sissi.jpg`
  * `EntenhausenPlanDetail.png`
  * `EntenhausenPlanDetail_annotation.ttl`
  * `sissiObjectLIDO.xml`
* `Staff work files`
  * `dagobert`
    * ~~`Dateien für Tick.zip`~~
    * `dieWollmilchsau.docx`
    * `dieWollmilchsau_final.docx`
    * `dieWollmilchsau_final.pdf`
    * `dieWollmilchsau_final FINAL.docx`
    * `dieWollmilchsau_korr1.docx`
    * `dieWollmilchsau_korr2.docx`
    * `dieWollmilchsauNEU.docx`
  * `DD`
    * `dieWollmilchsau_kp_DD.odt`
    * ~~`duckCharacters.csv`~~
  * `Donald`
    * `duckCharacters.csv`
    * `duckCharacters.xlsx`
* ~~`tempDagobert`~~
  * ~~`abb1.jpg`~~
  * ~~`Abbilding2.jpg`~~
  * ~~`dieWollmilchsau.docx`~~
  * ~~`dieWollmilchsau_finalFINAL.docx`~~
  * ~~`dieWollmilchsau_korr2.docx`~~
* `test`
  * ~~`duckCharacters.csv`~~
  * `Sebastian_Wallroth-Ente.wav`

### Discussion
* `0 OldFiles`: as the folder name already indicates, it supposedly contains old files; they were all copies of files found elsewhere in the collection
* `evenNewerStuff > 3d > ypm-ant248958.zip`: the zip just represents the already extracted folder `ypm-ant248958` and can be removed to avoid duplication
* `evenNewerStuff > DSC_5248_IslandOstfjorde Djúpivogur.jpg` and `evenNewerStuff > DSC_5255_IslandOstfjorde Djúpivogur WIS.jpg`: the file is just another format of the respective dng file; since dng is the format that stores more information and the jpg was supposedly generated from it, the latter could be removed
* `evenNewerStuff > DSC_5255_IslandOstfjorde Djúpivogur WIS.tiff`: althoug tiff is a format preferred over dng for long-term preservation, the existing dng is already enough and also contains more information
* `Staff work files > dagobert > Dateien für Tick.zip`: the zip contains files already located elsewhere and can be removed to avoid duplication
* `Staff work files > DD > duckCharacters.csv`: this csv is identical to `Staff work files > donald > duckCharacters.csv` and can be removed to avoid duplication
* `tempDagobert`: as the folder name already indicates, it supposedly contains files that are only temporarily of interest; although some files are named differently (e.g. `abb1.jpg` and `Abbilding2.jpg`), they can all be found elsewhere
* `test`: as the folder name indicates, it supposedly contains some files for testing, which can also be found elsewhere; this only applies to the file `duckCharacters.csv` which was removed, but `Sebastian_Wallroth-Ente.wav` is the only instance of this file which is why this is kept alongside the folder; in a real scenario one would ask project members about this file and either remove it or move it to its correct location



## File naming
When considering best practice:
* Use unambiguous and unique names
* Use descriptive names
* Be consistent
* As long as necessary, as short as possible
* Use date in ISO-format YYYY-MM-DD
* Indicate versioning
* Use leading zeros
* Do not use dots in file name
* Only use alphanumeric characters (letters from latin alphabet and numbers)
* Use hyphen (-) and underscore (_) for element separation

The following could be applied to this collection:
* `evenNewerStuff`
  * `3d`
    * `clay-duck` -> `clayDuck`
      * `source`
        * `model.zip`
      * `textures`
        * `lambert1_albedo.jpeg`
        * `lambert1_AO.jpeg`
        * `lambert1_metallic.jpeg`
        * `lambert1_normal.png`
        * `lambert1_roughness.jpeg`
    * `ypm-ant248958` -> `hopiDuckBowl_ypm-ant248958`
      * `source`
        * `medium.zip` -> `model.zip` (attention for file dependencies)
      * `textures`
        * `mesh_medium_u1_v1.png` -> `mesh_model_u1_v01.png` (attention for file dependencies)
    * `clay_duck_glTF.zip` -> `clayDuck_glTF.zip`
  * `postcards`
    * `01-a.jpg` -> `pc01_eDanielson_a.jpg`
    * `01-b.jpg` -> `pc01_eDanielson_b.jpg`
    * `02-a.jpg` -> `pc02_constantArtz_a.jpg`
    * `02-b.jpg` -> `pc02_constantArtz_b.jpg`
    * `03-a.jpg` -> `pc03_warnerBros_a.jpg`
    * `03-b.jpg` -> `pc03_warnerBros_b.jpg`
    * `04-back.jpg` -> `pc04_georgesLang_b.jpg`
    * `04-front.jpg` -> `pc04_georgesLang_a.jpg`
  * `00540901.jpg` -> `drawing_duckRoosterGoose_getty-83MR17225v.jpg`
  * `00938201.jpg` -> `photo_duckAskos_getty-78AE280a.jpg`
  * `15896001.jpg` -> `drawing_duckPond_getty-84XO70231720.jpg`
  * `20210712_080947_entenhausen.jpg` -> `photo_streetArtEntenhausen.jpg`
  * `20210712_080947_entenhausenCorr.jpg` -> `photo_streetArtEntenhausen_v02.jpg`
  * `Dame_Duck's_lecture_pg_6.jpg` -> `drawing_dameDucksLecture.jpg`
  * `DSC_5248_IslandOstfjorde Djúpivogur.dng` -> `photo_01icelandStoneDuck_Djupivogur.dng`
  * `DSC_5255_IslandOstfjorde Djúpivogur WIS.dng` -> `photo_02icelandStoneDuck_Djupivogur.dng`
  * `Duck_netsuke-Ethno_BHM_262-P6141097-gradient.jpg` -> `photo_clayDuckNetsuke_bhm-ethno-262.jpg`
  * `EierlegendeWollmilchSau.jpg` -> `clipart_wms_fGraf.jpg`
  * `Eierlegendewollmilchsau-Claire-Adele-02.jpg` -> `drawing_wms_cAdele.jpg`
  * `herkunft.md` -> `meta_fileSources.md`
  * `Stamp_of_Albania_-_2000_-_Colnect_370816_-_Donald_Duck_and_Daisy_Duck.jpeg` -> `stamp_donaldDaisyDuck_albania.jpeg`
  * `Wollmilchsau.jpg` -> `photoCollage_wms_gMittenecker.jpg`
  * `Wollmilchsau.png` -> `drawing_wms_pixelrausch.png`
* `newStuff`
  * `Blason_donaldville.svg` -> `coatOfArms_duckburg.svg`
  * `docs_meta.txt` -> `meta_fileSources.txt`
  * `duck_sissi.jpg` -> `painting_duckomentaSissi.jpg`
  * `EntenhausenPlanDetail.png` -> `map_duckburgDetail.png`
  * `EntenhausenPlanDetail_annotation.ttl` -> `map_duckburgDetail_annotation.ttl`
  * `sissiObjectLIDO.xml` -> `painting_duckomentaSissi_LIDO.xml`
* `Staff work files` -> `staffWorkFiles`
  * `dagobert` -> `dagobertDuck`
    * `dieWollmilchsau.docx` -> `article_wms_dagd_v01.docx`
    * `dieWollmilchsau_final.docx` -> `article_wms_dagd_v02-02.docx`
    * `dieWollmilchsau_final.pdf` -> `article_wms_dagd_v02-02.pdf`
    * `dieWollmilchsau_final FINAL.docx` -> `article_wms_dagd_v03-02.docx`
    * `dieWollmilchsau_korr1.docx` -> `article_wms_dagd_v02.docx`
    * `dieWollmilchsau_korr2.docx` -> `article_wms_dagd_v03.docx`
    * `dieWollmilchsauNEU.docx` -> `article_wms_dagd_v04.docx`
  * `DD` -> `daisyDuck`
    * `dieWollmilchsau_kp_DD.odt` -> `article_wms_dad_v01.odt`
  * `Donald` -> `donaldDuck`
    * `duckCharacters.csv` -> `table_duckCharacters_dod.csv`
    * `duckCharacters.xlsx` -> `table_duckCharacters_dod.xlsx`
* `test` -> `audio`
  * `Sebastian_Wallroth-Ente.wav` -> `recording_ente_sWallroth.wav`


### Discussion
The file naming conventions applied to the example solution here can be described as follows: 
* When a file starts with a letter, it is written in lower case
* camelCase is used to avoid spaces between coherent words
* Except for the 3d models, all files start with a term indicating the nature of the file, i.e. stating if it is a drawing, a photograph or a map. The abbreviation 'pc' is used for postcards. The term is then separated with an underscore with the remaining parts of the file name.
* The second part of the file name consinsts of terms joined in camelCase describing the content of the file. A number with leading zeros is prepended if some kind of order is required. The abbreviation 'wms' is used to describe 'Die eierlegende Wollmilchsau'.
* External authors/creators are included in the file name with the first letter of their first name and the full last name joined in camelCase.
* For project members the following abbreviations were introduced:
  * dagd: Dagobert Duck
  * dad: Daisy Duck
  * dod: Donald Duck
* The respective staff member working folders were harmonised with full names of contributors. Note that DD could also be 'Donald Duck', 'Dagobert Duck' or any other member.
* For any objects with inventory numbers available the inventory number was appended by indicating the institution with an abbreviation, followed by a hyphen and the actual inventory number without special characters. E.g. the object with the inventory number '78.AE.280.a' from the J. Paul Getty Museum becomes `getty-78AE280a`. The abbreviations in use are:
  * bhm: Bernisches Historisches Museum
  * getty: The J. Paul Getty Museum
  * ypm: Yale Peabody Museum of Natural History
* Versions are indicated with a lower case v followed by the major two-digit number. Minor and patch numbers are only indicated if they are unequal zero and are separated with a hyphen.
* For files belonging together the first part of the name was kept identical and further details were appended to keep them visually close to each other, e.g. `painting_duckomentaSissi.jpg` and `painting_duckomentaSissi_LIDO.xml`, where the latter technically isn't a painting, but a metadata file in LIDO XML format with metadata about the painting.

The names of `newStuff` and `evenNewerStuff` were kept in this step, as these will be removed in the folder restructuring step.


**Special attention:**
* Renaming of files that have dependencies, e.g. a 3d model and its textures, usually can't simply be done in a file browser but has to be done by opening and saving the files under new names.
* As 3d models usually consist of more than one file and these should be arranged in a consistent way, the names for the models (`model.zip`) and the containing folders (`source` and `textures`) were kept although they are then not unique anymore. But as on operating systems the path to a file is also part of identifying a file they then can be considered as unique.


## Folder structure
For this solution the files were simply rearranged by file type. Individual staff work folders were removed and the zip file `clay_duck_glTF.zip` was unpacked and merged with `3d > clay-duck`.

The resulting folder structure is as follows:

* `2dImages`
  * `drawingsPaintings`
    * `drawing_dameDucksLecture.jpg`
    * `drawing_duckPond_getty-84XO70231720.jpg`
    * `drawing_duckRoosterGoose_getty-83MR17225v.jpg`
    * `drawing_wms_cAdele.jpg`
    * `drawing_wms_pixelrausch.png`
    * `painting_duckomentaSissi.jpg`
    * `painting_duckomentaSissi_LIDO.xml`
  * `other`
    * `clipart_wms_fGraf.jpg`
    * `coatOfArms_duckburg.svg`
    * `stamp_donaldDaisyDuck_albania.jpeg`
  * `photographs`
    * `photo_01icelandStoneDuck_Djupivogur.dng`
    * `photo_02icelandStoneDuck_Djupivogur.dng`
    * `photo_clayDuckNetsuke_bhm-ethno-262.jpg`
    * `photoCollage_wms_gMittenecker.jpg`
    * `photo_duckAskos_getty-78AE280a.jpg`
    * `photo_streetArtEntenhausen.jpg`
    * `photo_streetArtEntenhausen_v02.jpg`
  * `postcards`
    * `pc01_eDanielson_a.jpg`
    * `pc01_eDanielson_b.jpg`
    * `pc02_constantArtz_a.jpg`
    * `pc02_constantArtz_b.jpg`
    * `pc03_warnerBros_a.jpg`
    * `pc03_warnerBros_b.jpg`
    * `pc04_georgesLang_a.jpg`
    * `pc04_georgesLang_b.jpg`
* `3d`
  * `clayDuck`
    * `source`
      * `model.zip`
      * `scene.bin`
      * `scene.gltf`
    * `textures`
      * `lambert1_albedo.jpeg`
      * `lambert1_AO.jpeg`
      * `lambert1_baseColor.jpeg`
      * `lambert1_metallic.jpeg`
      * `lambert1_metallicRoughness.png`
      * `lambert1_normal.png`
      * `lambert1_normal_glTF.png`
      * `lambert1_roughness.jpeg`
    * `license.txt`
  * `hopiDuckBowl_ypm-ant248958`
    * `source`
      * `model.zip`
    * `textures`
      * `mesh_model_u1_v01.png`
  * `articles`
    * `article_wms_dad_v01.odt`
    * `article_wms_dagd_v01.docx`
    * `article_wms_dagd_v02.docx`
    * `article_wms_dagd_v02-02.docx`
    * `article_wms_dagd_v02-02.pdf`
    * `article_wms_dagd_v03.docx`
    * `article_wms_dagd_v03-02.docx`
    * `article_wms_dagd_v04.docx`
* `audio`
  * `recording_ente_sWallroth.wav`
* `maps`
  * `map_duckburgDetail.png`
  * `map_duckburgDetail_annotation.ttl`   
* `tables`
  * `table_duckCharacters_dod.csv`
  * `table_duckCharacters_dod.xlsx`
* `meta_fileSources.md`
* `README.md`

### Discussion
* Of course this is one of many possible ways to structure the files. For example, an additional hierachy level could have been introduced by separating the files by content like *ducks* and *eierlegende Wollmilchsau*. 
* The two files `docs_meta.txt` and `meta_fileSources.md` were combined into a single file `meta_fileSources.md`, thus allowing the deletion of the first one.
* The folder `other` was included to avoid having many folders with just one file, which is then a bit uncomfortable to navigate.


## File formats
Here a list of the present file formats in the collection and a comment upon their suitability for long-term preservation is presented.
Consult [ARCHE - Formats](https://arche.acdh.oeaw.ac.at/browser/formats-filenames-and-metadata#formats) for an overview or [IANUS IT-Empfehlungen](https://ianus-fdz.de/it-empfehlungen/dateiformate) for an in depth discussion.

* audio formats
  * wav: Waveform Audio File Format, suitable
* image formats
  * dng: Adobe Digital Negative, suitable and preferred if a photograph was captured in RAW
  * jpg/jpeg: Joint Photographic Expert Group, not suitable but if the image was originally created in that format or the format is needed for technical requiremens might also be used for long-term preservation; a digital archive will help in deciding
  * png: Portable Network Graphics, not suitable for photographs, but simple graphics can be stored in this format
  * svg: Scalable Vector Graphis for vector images, suitable for long-term preservation if version 1.1 is used and file is uncompressed 
* text documents
  * docx: Office Open XML Document (Microsoft), while marked as suitable on ARCHE, usually a converted PDF/A is preferred
  * odt: Open Document Format, while marked as suitable on ARCHE, usually a converted PDF/A is preferred
  * pdf: Portable Document Format; if PDF/A-1 or PDF/A-2, suitable for long-term preservation 
* plain text, structured text, markup
  * md: markdown, suitable, because it basically is a plain text document following a specific syntax 
  * ttl: a plain text file following the turtle syntax, thus suitable for long-term preservation
  * txt: plain text
  * xml: eXtensible Markup Language, basically plain text but following a quite elaborate syntax
  * **important**: all plain text based files should be encoded in UTF-8 without BOM
* tabular
  * csv: a plain text format for tabular data suitable for long-term preservation
  * xlsx: Office Open XML Workbook (Microsoft), while marked as suitable on ARCHE, an export of all sheets into individual csv-files is preferred
* 3d 
  * bin: a compressed binary file, usually not suitable for long-term preservation
  * gltf: Graphics Language Transmission Format, glTF; a new standard for 3d files, which seems to be suitable for long-term preservation, because of its wide adaptation and it is an open standard (https://en.wikipedia.org/wiki/GlTF)
  * archive
    * zip: when it comes to long-term preservation zip files should be unpacked; for the 3d data this gives the formats `dae`, `jpg`, `png` and `mtl`, `obj`, `rcInfo`, `png`. Except for `rcInfo` the formats comply with current standards in 3d imaging and thus are suitable for long-term preservation